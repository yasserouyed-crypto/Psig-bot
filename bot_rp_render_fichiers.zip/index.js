const {
  Client,
  GatewayIntentBits,
  Events,
  EmbedBuilder,
  PermissionsBitField
} = require("discord.js");

const PREFIX = /^rp!/i;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once(Events.ClientReady, (bot) => {
  console.log(`✅ Bot connecté : ${bot.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot || !message.guild) return;
  if (!PREFIX.test(message.content)) return;

  const content = message.content.slice(3).trim();
  if (!content) return;

  const args = content.split(/\s+/);
  const command = (args.shift() || "").toLowerCase();

  try {
    if (command === "help") {
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle("📋 Commandes du bot RP")
        .setDescription([
          "`RP!help` — Afficher l'aide",
          "`RP!ping` — Vérifier la latence",
          "`RP!info` — Informations sur le bot",
          "`RP!server` — Informations sur le serveur",
          "`RP!avatar [@membre]` — Afficher un avatar",
          "`RP!userinfo [@membre]` — Informations sur un membre",
          "`RP!clear <nombre>` — Supprimer des messages (permission requise)",
          "`RP!lock` — Verrouiller le salon (permission requise)",
          "`RP!unlock` — Déverrouiller le salon (permission requise)",
          "`RP!say <message>` — Envoyer un message (permission requise)"
        ].join("\n"))
        .setFooter({ text: "Bot RP • Préfixe RP! (insensible à la casse)" });
      return message.reply({ embeds: [embed] });
    }

    if (command === "ping") {
      return message.reply(`🏓 Pong ! Latence : ${client.ws.ping} ms`);
    }

    if (command === "info") {
      return message.reply(
        `🤖 Je suis **${client.user.tag}**.\nServeurs : **${client.guilds.cache.size}**`
      );
    }

    if (command === "server") {
      const guild = message.guild;
      const embed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle(`📌 ${guild.name}`)
        .addFields(
          { name: "Membres (approx.)", value: `${guild.memberCount}`, inline: true },
          { name: "Salons", value: `${guild.channels.cache.size}`, inline: true },
          { name: "Créé le", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
        );
      return message.reply({ embeds: [embed] });
    }

    if (command === "avatar") {
      const member = message.mentions.users.first() || message.author;
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(`Avatar de ${member.tag}`)
        .setImage(member.displayAvatarURL({ size: 1024 }));
      return message.reply({ embeds: [embed] });
    }

    if (command === "userinfo") {
      const user = message.mentions.users.first() || message.author;
      const member = await message.guild.members.fetch(user.id).catch(() => null);
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(`👤 ${user.tag}`)
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields(
          { name: "ID", value: user.id },
          { name: "Compte créé", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` },
          { name: "A rejoint le serveur", value: member?.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` : "Inconnu" }
        );
      return message.reply({ embeds: [embed] });
    }

    if (command === "clear") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        return message.reply("❌ Il te faut la permission **Gérer les messages**.");
      }
      const amount = Number.parseInt(args[0], 10);
      if (!Number.isInteger(amount) || amount < 1 || amount > 100) {
        return message.reply("Utilisation : `RP!clear <1 à 100>`");
      }
      const deleted = await message.channel.bulkDelete(amount + 1, true);
      const response = await message.channel.send(`🧹 ${Math.max(0, deleted.size - 1)} message(s) supprimé(s).`);
      setTimeout(() => response.delete().catch(() => {}), 5000);
      return;
    }

    if (command === "lock" || command === "unlock") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.reply("❌ Il te faut la permission **Gérer les salons**.");
      }
      const everyone = message.guild.roles.everyone;
      const locked = command === "lock";
      await message.channel.permissionOverwrites.edit(everyone, {
        SendMessages: locked ? false : null
      });
      return message.reply(locked ? "🔒 Salon verrouillé." : "🔓 Salon déverrouillé.");
    }

    if (command === "say") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        return message.reply("❌ Il te faut la permission **Gérer les messages**.");
      }
      const text = args.join(" ");
      if (!text) return message.reply("Utilisation : `RP!say <message>`");
      return message.channel.send({ content: text, allowedMentions: { parse: [] } });
    }
  } catch (error) {
    console.error(`Erreur avec la commande ${command}:`, error);
    return message.reply("❌ Une erreur est survenue. Vérifie les permissions du bot et les logs Render.")
      .catch(() => {});
  }
});

client.on(Events.Error, (error) => console.error("Erreur Discord :", error));

client.login(process.env.DISCORD_TOKEN).catch((error) => {
  console.error("Impossible de connecter le bot. Vérifie DISCORD_TOKEN dans Render.", error);
  process.exit(1);
});
