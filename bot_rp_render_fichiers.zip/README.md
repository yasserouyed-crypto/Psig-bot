# Bot RP — Render

## Fichiers
- `index.js` : lance le bot et gère des commandes avec préfixe `RP!`, `Rp!`, `rp!`.
- `package.json` : dépendances et commandes de démarrage.
- `deploy-commands.js` : garde ton fichier existant pour les commandes slash. Il n'est pas inclus ici car son contenu est inconnu.

## Installation
1. Ajoute `index.js` et `package.json` à la racine du dépôt GitHub.
2. Dans Discord Developer Portal > Application > Bot, active **Message Content Intent**.
3. Dans Render > ton service > Environment, ajoute `DISCORD_TOKEN` avec le token du bot. Ne le mets pas dans GitHub.
4. Dans Render > Settings, mets la commande de démarrage à `npm start`.
5. Vérifie que le bot possède les permissions nécessaires dans le serveur Discord.
6. Dans Discord, teste `RP!ping`, `Rp!help`, `RP!avatar`.

## Commandes incluses
- `RP!help`
- `RP!ping`
- `RP!info`
- `RP!server`
- `RP!avatar [@membre]`
- `RP!userinfo [@membre]`
- `RP!clear <1-100>` — nécessite Gérer les messages
- `RP!lock` et `RP!unlock` — nécessitent Gérer les salons
- `RP!say <message>` — nécessite Gérer les messages

## Important pour les commandes slash
Ne supprime pas `deploy-commands.js`. Le fichier de déploiement slash et le processus du bot sont deux choses distinctes. Le contenu actuel de `deploy-commands.js` n'a pas été modifié. Si ce fichier a d'autres dépendances que `discord.js`, ajoute-les à `package.json`.
