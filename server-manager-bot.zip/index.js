const {
  Client, GatewayIntentBits, PermissionsBitField, EmbedBuilder,
  ChannelType
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const config = require("./config.json");
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const DATA = path.join(__dirname, "data");
for (const file of ["blacklist.json","warnings.json","config.json","preuves.json"]) {
  const p = path.join(DATA,file);
  if (!fs.existsSync(p)) fs.writeFileSync(p, "{}");
}
function load(name){ return JSON.parse(fs.readFileSync(path.join(DATA,name),"utf8")); }
function save(name,data){ fs.writeFileSync(path.join(DATA,name), JSON.stringify(data,null,2)); }

const blacklist = load("blacklist.json");
const warnings = load("warnings.json");
const preuves = load("preuves.json");
const guildSettings = load("config.json");

function isStaff(message){
  return message.member?.permissions.has(PermissionsBitField.Flags.Administrator) ||
    (config.staffRoleId && message.member?.roles.cache.has(config.staffRoleId));
}
async function log(guild, title, description, color=0x5865F2){
  const id=config.logChannelId;
  const channel=id ? guild.channels.cache.get(id) : null;
  if(!channel) return;
  const embed=new EmbedBuilder().setTitle(title).setDescription(description)
    .setColor(color).setTimestamp();
  await channel.send({embeds:[embed]}).catch(()=>{});
}
function getSettings(guildId){
  if(!guildSettings[guildId]) guildSettings[guildId]={
    automod:{...config.automod}, raidMode:false,
    welcomeChannelId:config.welcomeChannelId,
    goodbyeChannelId:config.goodbyeChannelId
  };
  return guildSettings[guildId];
}
function argsOf(content){ return content.trim().split(/\s+/).slice(1); }

client.once("ready", ()=>{
  console.log(`Connecté : ${client.user.tag}`);
  client.user.setActivity("s!help | Server Manager", {type:3});
});

client.on("guildMemberAdd", async member=>{
  const s=getSettings(member.guild.id);
  if(s.raidMode){
    await member.timeout(60_000,"Mode raid actif").catch(()=>{});
  }
  const ch=member.guild.channels.cache.get(s.welcomeChannelId);
  if(ch) ch.send({content:`👋 Bienvenue ${member} sur **${member.guild.name}** !`}).catch(()=>{});
  await log(member.guild,"🟢 Arrivée",`${member.user.tag} (${member.id})`);
});
client.on("guildMemberRemove", async member=>{
  const s=getSettings(member.guild.id);
  const ch=member.guild.channels.cache.get(s.goodbyeChannelId);
  if(ch) ch.send({content:`🔴 **${member.user.tag}** vient de quitter le serveur.`}).catch(()=>{});
  await log(member.guild,"🔴 Départ",`${member.user.tag} (${member.id})`);
});

client.on("messageCreate", async message=>{
  if(message.author.bot || !message.guild) return;
  const s=getSettings(message.guild.id);

  if(blacklist[message.guild.id]?.[message.author.id]){
    await message.delete().catch(()=>{});
    return;
  }
  if(s.automod?.enabled && !isStaff(message)){
    const content=message.content.toLowerCase();
    const words=s.automod.badWords||[];
    const invite=/discord(?:\.gg|\.com\/invite)\/[a-z0-9-]+/i.test(message.content);
    const link=/https?:\/\/\S+/i.test(message.content);
    const bad=words.some(w=>w && content.includes(w.toLowerCase()));
    const tooManyMentions=message.mentions.users.size >= (s.automod.maxMentions||5);
    if((s.automod.antiInvite && invite) || (s.automod.antiLink && link) || bad || tooManyMentions){
      await message.delete().catch(()=>{});
      await message.member.timeout(10_000,"AutoMod").catch(()=>{});
      await log(message.guild,"🛡️ AutoMod",`${message.author} : message supprimé et sanction automatique.`,0xED4245);
      return;
    }
    if(s.automod.antiSpam){
      const key=`${message.guild.id}:${message.author.id}`;
      const now=Date.now();
      spam.set(key,(spam.get(key)||[]).filter(t=>now-t<5000).concat(now));
      if(spam.get(key).length>=6){
        spam.delete(key);
        await message.member.timeout(30_000,"Spam").catch(()=>{});
        await log(message.guild,"🚨 Anti-spam",`${message.author} timeout pour spam.`,0xED4245);
      }
    }
  }

  if(!message.content.toLowerCase().startsWith(config.prefix.toLowerCase())) return;
  const [raw,...args]=argsOf(message.content);
  const cmd=raw.toLowerCase();

  if(cmd==="help"){
    return message.reply({embeds:[new EmbedBuilder().setTitle("🛠️ Server Manager")
      .setDescription([
        "**Sécurité**","`s!sos [motif]` • `s!raidmode on/off` • `s!lockdown` • `s!unlockdown`",
        "**Staff**","`s!staffpreuve @membre [preuve]` • `s!rapport [texte]` • `s!sanction @membre [raison]`",
        "**Modération**","`s!ban @membre [raison]` • `s!unban ID` • `s!kick @membre [raison]`",
        "`s!warn @membre [raison]` • `s!warnings @membre` • `s!clear [nombre]`",
        "`s!timeout @membre [secondes] [raison]` • `s!untimeout @membre`",
        "**Blacklist**","`s!blacklist @membre [raison]` • `s!unblacklist @membre` • `s!blacklistlist`",
        "**AutoMod**","`s!automod on/off` • `s!antilink on/off` • `s!antispam on/off`",
        "**Infos**","`s!userinfo @membre` • `s!serverinfo` • `s!logs`"
      ].join("\n")).setColor(0x5865F2)]});
  }

  if(!isStaff(message) && !["userinfo","serverinfo"].includes(cmd))
    return message.reply("❌ Commande réservée au staff.");

  const target=message.mentions.members.first();
  const reason=args.slice(target?1:0).join(" ") || "Aucune raison indiquée";

  if(cmd==="sos"){
    const motif=args.join(" ")||"Aucun motif";
    const ch=config.sosChannelId ? message.guild.channels.cache.get(config.sosChannelId) : message.channel;
    const embed=new EmbedBuilder().setTitle("🚨 SOS RAID")
      .setDescription(`**Motif :** ${motif}\n**Déclenché par :** ${message.author}\n**Serveur :** ${message.guild.name}`)
      .setColor(0xED4245).setTimestamp();
    await ch.send({content:config.mentionEveryoneOnSOS?"@everyone":undefined,embeds:[embed],allowedMentions:{parse:config.mentionEveryoneOnSOS?["everyone"]:[]}}).catch(()=>{});
    return message.reply("🚨 SOS envoyé.");
  }

  if(cmd==="raidmode"){
    const mode=(args[0]||"on").toLowerCase();
    getSettings(message.guild.id).raidMode=mode!=="off";
    save("config.json",guildSettings);
    return message.reply(mode==="off"?"🟢 Mode raid désactivé.":"🔴 Mode raid activé.");
  }

  if(cmd==="lockdown" || cmd==="unlockdown"){
    const lock=cmd==="lockdown";
    const channels=message.guild.channels.cache.filter(c=>c.type===ChannelType.GuildText);
    for(const [,ch] of channels){
      await ch.permissionOverwrites.edit(message.guild.roles.everyone.id,{
        SendMessages: lock ? false : null
      }).catch(()=>{});
    }
    await log(message.guild,lock?"🔒 Lockdown":"🔓 Unlockdown",`${message.author.tag}`);
    return message.reply(lock?"🔒 Serveur verrouillé.":"🔓 Serveur déverrouillé.");
  }

  if(cmd==="staffpreuve"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    const preuve=args.slice(1).join(" ")||"Aucune preuve détaillée.";
    if(!preuves[message.guild.id]) preuves[message.guild.id]={};
    if(!preuves[message.guild.id][target.id]) preuves[message.guild.id][target.id]=[];
    preuves[message.guild.id][target.id].push({staff:message.author.id,preuve,date:new Date().toISOString()});
    save("preuves.json",preuves);
    await log(message.guild,"📁 Preuve staff",`Membre : ${target}\nStaff : ${message.author}\nPreuve : ${preuve}`);
    return message.reply("✅ Preuve staff enregistrée.");
  }

  if(cmd==="rapport"){
    const text=args.join(" ")||"Rapport vide.";
    await log(message.guild,"📋 Rapport staff",`Auteur : ${message.author}\n\n${text}`,0xFEE75C);
    return message.reply("✅ Rapport enregistré dans les logs.");
  }

  if(cmd==="sanction"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    await log(message.guild,"⚖️ Sanction",`Membre : ${target}\nStaff : ${message.author}\nRaison : ${reason}`,0xED4245);
    return message.reply("✅ Sanction enregistrée dans les logs.");
  }

  if(cmd==="ban"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    await target.ban({reason});
    await log(message.guild,"🔨 Ban",`${target.user.tag}\n${reason}`,0xED4245);
    return message.reply(`🔨 ${target.user.tag} a été banni.`);
  }
  if(cmd==="unban"){
    const id=args[0]; if(!id) return message.reply("❌ Donne un ID.");
    await message.guild.members.unban(id,reason).catch(()=>{});
    return message.reply("✅ Tentative de débannissement effectuée.");
  }
  if(cmd==="kick"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    await target.kick(reason);
    await log(message.guild,"👢 Kick",`${target.user.tag}\n${reason}`,0xED4245);
    return message.reply(`👢 ${target.user.tag} a été expulsé.`);
  }
  if(cmd==="warn"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    if(!warnings[message.guild.id]) warnings[message.guild.id]={};
    if(!warnings[message.guild.id][target.id]) warnings[message.guild.id][target.id]=[];
    warnings[message.guild.id][target.id].push({staff:message.author.id,reason,date:new Date().toISOString()});
    save("warnings.json",warnings);
    return message.reply(`⚠️ ${target.user.tag} a reçu un avertissement.`);
  }
  if(cmd==="warnings"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    const list=warnings[message.guild.id]?.[target.id]||[];
    return message.reply(`⚠️ **${target.user.tag}** : ${list.length} avertissement(s).`);
  }
  if(cmd==="clear"){
    const n=Math.min(Math.max(parseInt(args[0])||10,1),100);
    const deleted=await message.channel.bulkDelete(n,true);
    return message.reply(`🧹 ${deleted.size} message(s) supprimé(s).`).then(m=>setTimeout(()=>m.delete().catch(()=>{}),3000));
  }
  if(cmd==="timeout"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    const seconds=Math.min(Math.max(parseInt(args[1])||60,1),2419200);
    await target.timeout(seconds*1000,reason);
    return message.reply(`⏱️ ${target.user.tag} timeout ${seconds}s.`);
  }
  if(cmd==="untimeout"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    await target.timeout(null,"Retrait du timeout");
    return message.reply(`✅ Timeout retiré à ${target.user.tag}.`);
  }

  if(cmd==="blacklist"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    if(!blacklist[message.guild.id]) blacklist[message.guild.id]={};
    blacklist[message.guild.id][target.id]={reason,date:new Date().toISOString(),staff:message.author.id};
    save("blacklist.json",blacklist);
    if(config.blacklistRoleId) await target.roles.add(config.blacklistRoleId).catch(()=>{});
    await log(message.guild,"🚫 Blacklist",`${target}\nRaison : ${reason}`,0xED4245);
    return message.reply(`🚫 ${target.user.tag} a été blacklisté.`);
  }
  if(cmd==="unblacklist"){
    if(!target) return message.reply("❌ Mentionne un membre.");
    delete blacklist[message.guild.id]?.[target.id];
    save("blacklist.json",blacklist);
    if(config.blacklistRoleId) await target.roles.remove(config.blacklistRoleId).catch(()=>{});
    return message.reply(`✅ ${target.user.tag} retiré de la blacklist.`);
  }
  if(cmd==="blacklistlist"){
    const list=Object.keys(blacklist[message.guild.id]||{});
    return message.reply(list.length?`🚫 Blacklist : ${list.map(id=>`<@${id}>`).join(", ")}`:"✅ Blacklist vide.");
  }

  if(cmd==="automod"){
    const on=(args[0]||"on").toLowerCase()!=="off";
    getSettings(message.guild.id).automod.enabled=on; save("config.json",guildSettings);
    return message.reply(on?"🛡️ AutoMod activé.":"🔕 AutoMod désactivé.");
  }
  if(cmd==="antilink"){
    const on=(args[0]||"on").toLowerCase()!=="off";
    getSettings(message.guild.id).automod.antiLink=on; save("config.json",guildSettings);
    return message.reply(on?"🔗 Anti-link activé.":"🔗 Anti-link désactivé.");
  }
  if(cmd==="antispam"){
    const on=(args[0]||"on").toLowerCase()!=="off";
    getSettings(message.guild.id).automod.antiSpam=on; save("config.json",guildSettings);
    return message.reply(on?"🛡️ Anti-spam activé.":"🛡️ Anti-spam désactivé.");
  }

  if(cmd==="userinfo"){
    const m=target||message.member;
    return message.reply({embeds:[new EmbedBuilder().setTitle("👤 Informations membre")
      .addFields(
        {name:"Utilisateur",value:`${m.user.tag}`,inline:true},
        {name:"ID",value:m.id,inline:true},
        {name:"Compte créé",value:`<t:${Math.floor(m.user.createdTimestamp/1000)}:F>`,inline:false},
        {name:"Rejoint",value:m.joinedTimestamp?`<t:${Math.floor(m.joinedTimestamp/1000)}:F>`:"Inconnu",inline:false}
      ).setThumbnail(m.user.displayAvatarURL()).setColor(0x5865F2)]});
  }
  if(cmd==="serverinfo"){
    return message.reply({embeds:[new EmbedBuilder().setTitle("🏠 Informations serveur")
      .addFields(
        {name:"Nom",value:message.guild.name,inline:true},
        {name:"ID",value:message.guild.id,inline:true},
        {name:"Membres",value:String(message.guild.memberCount),inline:true},
        {name:"Salons",value:String(message.guild.channels.cache.size),inline:true},
        {name:"Créé",value:`<t:${Math.floor(message.guild.createdTimestamp/1000)}:F>`,inline:false}
      ).setColor(0x5865F2)]});
  }
});

const spam=new Map();
client.login(config.token);
