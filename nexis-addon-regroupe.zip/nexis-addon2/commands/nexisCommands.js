const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { loadConfig, saveConfig } = require('../utils/configManager');

module.exports = [
  // ─────────────────────────────────────────────
  // s!config → TOUTE la config du bot en une seule commande
  // s!config grade add <nom> @role
  // s!config grade remove <nom>
  // s!config sos #salon
  // s!config list
  // ─────────────────────────────────────────────
  {
    name: 'config',
    async execute(message, args) {
      if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply('❌ Réservé aux administrateurs.');
      }

      const config = loadConfig(message.guild.id);
      const section = args[0]; // grade | sos | list

      // s!config list → affiche toute la config d'un coup
      if (section === 'list') {
        const grades = Object.entries(config.grades);
        const gradesText = grades.length
          ? grades.map(([name, id]) => `• **${name}** → <@&${id}>`).join('\n')
          : 'Aucun';
        const sosText = config.sosChannel ? `<#${config.sosChannel}>` : 'Non configuré';

        const ownerText = config.ownerId ? `<@${config.ownerId}>` : 'Non défini';
        const ownerChannelsText = config.ownerChannels.length
          ? config.ownerChannels.map(id => `<#${id}>`).join(', ')
          : 'Aucun';

        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle('⚙️ Configuration Nexis Bot')
          .addFields(
            { name: 'Grades', value: gradesText },
            { name: 'Salon SOS', value: sosText },
            { name: 'Lien support', value: config.supportLink || 'Non défini' },
            { name: 'Owner', value: ownerText },
            { name: 'Salons d\'annonce owner', value: ownerChannelsText }
          );
        return message.channel.send({ embeds: [embed] });
      }

      // s!config grade add <nom> @role  |  s!config grade remove <nom>
      if (section === 'grade') {
        const action = args[1]; // add | remove

        if (action === 'add') {
          const role = message.mentions.roles.first();
          const gradeName = args.slice(2).filter(a => !/^<@&\d+>$/.test(a)).join(' ').trim();
          if (!role || !gradeName) {
            return message.reply('❌ Usage : `s!config grade add <nom> @role`');
          }
          config.grades[gradeName.toLowerCase()] = role.id;
          saveConfig(message.guild.id, config);
          return message.reply(`✅ Grade **${gradeName}** lié au rôle ${role}.`);
        }

        if (action === 'remove') {
          const gradeName = args.slice(2).join(' ').trim().toLowerCase();
          if (!gradeName || !config.grades[gradeName]) {
            return message.reply('❌ Grade introuvable.');
          }
          delete config.grades[gradeName];
          saveConfig(message.guild.id, config);
          return message.reply(`✅ Grade **${gradeName}** supprimé.`);
        }

        return message.reply('❌ Usage : `s!config grade add <nom> @role` ou `s!config grade remove <nom>`');
      }

      // s!config sos #salon
      if (section === 'sos') {
        const channel = message.mentions.channels.first();
        if (!channel) {
          return message.reply('❌ Usage : `s!config sos #salon`');
        }
        config.sosChannel = channel.id;
        saveConfig(message.guild.id, config);
        return message.reply(`✅ Les alertes SOS seront envoyées dans ${channel}.`);
      }

      // s!config support <lien>
      if (section === 'support') {
        const link = args[1];
        if (!link) return message.reply('❌ Usage : `s!config support <lien>`');
        config.supportLink = link;
        saveConfig(message.guild.id, config);
        return message.reply(`✅ Lien support défini : ${link}`);
      }

      // s!config owner @utilisateur
      if (section === 'owner') {
        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Usage : `s!config owner @utilisateur`');
        config.ownerId = user.id;
        saveConfig(message.guild.id, config);
        return message.reply(`✅ ${user.tag} est maintenant reconnu comme owner du bot.`);
      }

      // s!config ownerchannel add|remove #salon
      if (section === 'ownerchannel') {
        const action = args[1];
        const channel = message.mentions.channels.first();
        if (!['add', 'remove'].includes(action) || !channel) {
          return message.reply('❌ Usage : `s!config ownerchannel add #salon` ou `s!config ownerchannel remove #salon`');
        }
        if (action === 'add') {
          if (!config.ownerChannels.includes(channel.id)) config.ownerChannels.push(channel.id);
          saveConfig(message.guild.id, config);
          return message.reply(`✅ ${channel} annoncera l'arrivée de l'owner.`);
        } else {
          config.ownerChannels = config.ownerChannels.filter(id => id !== channel.id);
          saveConfig(message.guild.id, config);
          return message.reply(`✅ ${channel} ne l'annoncera plus.`);
        }
      }

      return message.reply(
        '❌ Usage :\n' +
        '`s!config grade add <nom> @role`\n' +
        '`s!config grade remove <nom>`\n' +
        '`s!config sos #salon`\n' +
        '`s!config support <lien>`\n' +
        '`s!config owner @utilisateur`\n' +
        '`s!config ownerchannel add|remove #salon`\n' +
        '`s!config list`'
      );
    }
  },

  // ─────────────────────────────────────────────
  // s!preuvestaff @utilisateur <grade>
  // ─────────────────────────────────────────────
  {
    name: 'preuvestaff',
    async execute(message, args) {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return message.reply('❌ Tu n\'as pas la permission d\'utiliser cette commande.');
      }

      const target = message.mentions.members.first();
      const gradeName = args.slice(1).join(' ').trim();

      if (!target || !gradeName) {
        return message.reply('❌ Usage : `s!preuvestaff @utilisateur <grade>`');
      }

      const config = loadConfig(message.guild.id);
      const roleId = config.grades[gradeName.toLowerCase()];

      if (!roleId) {
        return message.reply(`❌ Le grade **${gradeName}** n'existe pas. Configure-le avec \`s!config grade add <nom> @role\`.`);
      }

      const role = message.guild.roles.cache.get(roleId);
      if (!role) {
        return message.reply('❌ Le rôle configuré pour ce grade est introuvable.');
      }

      if (!target.roles.cache.has(role.id)) {
        await target.roles.add(role).catch(() => null);
      }

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🛡️ Preuve Staff')
        .addFields(
          { name: 'Utilisateur', value: `${target.user.tag}`, inline: false },
          { name: 'ID', value: `\`${target.id}\``, inline: false },
          { name: 'Grade', value: `**${gradeName}**`, inline: false }
        )
        .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`Cet utilisateur est membre du staff officiel de **${message.guild.name}**.`)
        .setTimestamp();

      return message.channel.send({ embeds: [embed] });
    }
  },

  // ─────────────────────────────────────────────
  // s!grade add|remove @utilisateur <grade>  (donne/retire juste le rôle, sans embed)
  // ─────────────────────────────────────────────
  {
    name: 'grade',
    async execute(message, args) {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return message.reply('❌ Tu n\'as pas la permission d\'utiliser cette commande.');
      }

      const sub = args[0];
      const target = message.mentions.members.first();
      const gradeName = args.slice(2).join(' ').trim();

      if (!['add', 'remove'].includes(sub) || !target || !gradeName) {
        return message.reply('❌ Usage : `s!grade add @utilisateur <grade>` ou `s!grade remove @utilisateur <grade>`');
      }

      const config = loadConfig(message.guild.id);
      const roleId = config.grades[gradeName.toLowerCase()];
      if (!roleId) return message.reply(`❌ Le grade **${gradeName}** n'existe pas.`);

      const role = message.guild.roles.cache.get(roleId);
      if (!role) return message.reply('❌ Rôle introuvable.');

      if (sub === 'add') {
        await target.roles.add(role).catch(() => null);
        return message.reply(`✅ Grade **${gradeName}** attribué à ${target.user.tag}.`);
      } else {
        await target.roles.remove(role).catch(() => null);
        return message.reply(`✅ Grade **${gradeName}** retiré à ${target.user.tag}.`);
      }
    }
  },

  // ─────────────────────────────────────────────
  // s!sos <raison>
  // ─────────────────────────────────────────────
  {
    name: 'sos',
    async execute(message, args) {
      const reason = args.join(' ').trim();
      if (!reason) return message.reply('❌ Usage : `s!sos <raison>`');

      const config = loadConfig(message.guild.id);
      if (!config.sosChannel) {
        return message.reply('❌ Aucun salon SOS configuré. Un admin doit faire `s!config sos #salon`.');
      }

      const targetChannel = message.guild.channels.cache.get(config.sosChannel);
      if (!targetChannel) return message.reply('❌ Le salon SOS configuré est introuvable.');

      let inviteUrl = 'Indisponible';
      try {
        if (message.channel.permissionsFor(message.guild.members.me).has(PermissionFlagsBits.CreateInstantInvite)) {
          const invite = await message.channel.createInvite({ maxAge: 3600, maxUses: 1, unique: true });
          inviteUrl = invite.url;
        }
      } catch {
        // pas grave, on continue sans invite
      }

      const embed = new EmbedBuilder()
        .setColor(0xED4245)
        .setTitle('🚨 Alerte SOS')
        .addFields(
          { name: 'Serveur', value: message.guild.name, inline: true },
          { name: 'Demandé par', value: `${message.author.tag}`, inline: true },
          { name: 'Raison', value: reason, inline: false },
          { name: 'Lien du serveur', value: inviteUrl, inline: false }
        )
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`sosaccept_${message.author.id}_${message.guild.id}`)
          .setLabel('✅ Accepter')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`sosdecline_${message.author.id}_${message.guild.id}`)
          .setLabel('❌ Refuser')
          .setStyle(ButtonStyle.Danger)
      );

      await targetChannel.send({ embeds: [embed], components: [row] });
      return message.reply('✅ Ta demande d\'aide a été envoyée au staff.');
    }
  }
];
