# Addon Nexis Bot (version regroupée + messages riches)

## Commandes
- `s!preuvestaff @utilisateur <grade>` → embed "Preuve Staff" + donne le rôle
- `s!grade add|remove @utilisateur <grade>` → donne/retire juste le rôle
- `s!sos <raison>` → alerte le staff (lien du serveur + boutons Accepter/Refuser)
- `s!config grade add <nom> @role` / `remove <nom>` → gère les grades
- `s!config sos #salon` → salon où arrivent les alertes SOS
- `s!config support <lien>` → lien affiché dans le message "SOS résolu" (ex: ton Discord)
- `s!config owner @utilisateur` → qui est reconnu comme "owner" du bot
- `s!config ownerchannel add|remove #salon` → salons où annoncer l'arrivée de l'owner
- `s!config list` → toute la config en un coup d'œil

## Les deux messages automatiques que tu voulais

**"SOS résolu"** (DM envoyé à la personne qui a fait `s!sos`, dès qu'un staff clique sur ✅ Accepter) :
géré dans `events/sosButtons.js`, avec le lien support si tu l'as configuré (`s!config support <lien>`).

**"Owner détecté"** (annoncé automatiquement dans un salon quand ton owner y écrit) :
géré dans `events/ownerDetect.js`. Cooldown de 30 min pour ne pas spammer à chaque message.

## Installation
1. Place `commands/nexisCommands.js`, `utils/configManager.js`, `events/sosButtons.js` et `events/ownerDetect.js` dans ton repo, aux mêmes emplacements.
2. Chargement des commandes (tableau) :
   ```js
   const nexisCommands = require('./commands/nexisCommands');
   nexisCommands.forEach(cmd => client.commands.set(cmd.name, cmd));
   ```
3. Dans ton `interactionCreate` existant :
   ```js
   const handleSosButtons = require('./events/sosButtons');
   client.on('interactionCreate', async (interaction) => {
     if (await handleSosButtons(interaction, client)) return;
     // ... reste de ton code existant
   });
   ```
4. Dans ton `messageCreate` existant (avant ou après le traitement des commandes préfixe, peu importe) :
   ```js
   const handleOwnerDetect = require('./events/ownerDetect');
   client.on('messageCreate', async (message) => {
     await handleOwnerDetect(message, client);
     // ... reste de ton code existant (lecture des commandes préfixe, etc.)
   });
   ```
5. Le bot doit avoir la permission **Gérer les rôles**, avec son rôle au-dessus des rôles de grade.
6. Redéploie sur Render.

⚠️ Config stockée en JSON local (`data/configs/<idServeur>.json`) → réinitialisée à chaque redéploiement sur Render gratuit. Dis-moi si tu veux passer sur une vraie DB pour que ça tienne dans le temps.

## Test rapide
```
s!config grade add Bêta Testeur @Bêta Testeur
s!config sos #alertes-sos
s!config support https://discord.gg/tonserveur
s!config owner @toi
s!config ownerchannel add #partenariats
s!config list
s!preuvestaff @hvk_shadowoff Bêta Testeur
s!sos Un joueur RP hors des règles
```
