const { EmbedBuilder } = require('discord.js');
const { loadConfig, saveConfig } = require('../utils/configManager');

const COOLDOWN_MS = 30 * 60 * 1000; // 30 minutes entre deux annonces sur le même serveur

// À brancher sur l'event "messageCreate" de ton bot principal.
// Appelle handleOwnerDetect(message, client) au début de ton listener existant.

module.exports = async function handleOwnerDetect(message, client) {
  if (!message.guild || message.author.bot) return false;

  const config = loadConfig(message.guild.id);
  if (!config.ownerId || config.ownerId !== message.author.id) return false;
  if (!config.ownerChannels.includes(message.channel.id)) return false;

  const now = Date.now();
  if (now - (config.lastOwnerAnnounce || 0) < COOLDOWN_MS) return false;

  config.lastOwnerAnnounce = now;
  saveConfig(message.guild.id, config);

  const embed = new EmbedBuilder()
    .setColor(0xFEE75C)
    .setTitle('👑 Owner détecté')
    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
    .setDescription(
      `Accrochez-vous, **${message.author.username}** vient de faire son entrée — le créateur de **${client.user.username}** en chair et en os.\n\n` +
      `Une question, un bug, une idée ? C'est le bon moment pour lui en parler.\n` +
      `🙏 Petit rappel : on évite le spam et les pings en boucle.\n\n` +
      `💙 Merci d'être là.`
    );

  await message.channel.send({ embeds: [embed] }).catch(() => null);
  return true;
};
