const { EmbedBuilder } = require('discord.js');
const { loadConfig } = require('../utils/configManager');

// À brancher sur l'event "interactionCreate" de ton bot principal.
// Si tu as déjà un handler interactionCreate pour d'autres boutons/slash,
// ajoute juste ce bloc dedans plutôt que de créer un second listener.

module.exports = async function handleSosButtons(interaction, client) {
  if (!interaction.isButton()) return false;
  if (!interaction.customId.startsWith('sosaccept_') && !interaction.customId.startsWith('sosdecline_')) {
    return false; // pas un bouton SOS, on laisse la main à un autre handler
  }

  const isAccept = interaction.customId.startsWith('sosaccept_');
  const [, requesterId, guildId] = interaction.customId.split('_');

  await interaction.update({ components: [] });

  const guild = client.guilds.cache.get(guildId);
  const config = guild ? loadConfig(guildId) : null;
  const user = await client.users.fetch(requesterId).catch(() => null);

  if (isAccept) {
    await interaction.followUp(`✅ ${interaction.user} a accepté de prendre en charge cette demande.`);

    if (user && guild) {
      const embed = new EmbedBuilder()
        .setColor(0xED4245)
        .setTitle('🆘 SOS résolu')
        .setThumbnail(client.user.displayAvatarURL())
        .setDescription(
          `🚨 Une alerte SOS a été déclenchée sur votre serveur **${guild.name}**.\n\n` +
          `✅ La situation a été prise en charge par notre équipe.\n\n` +
          `Après vérification, les mesures nécessaires ont été prises afin de résoudre l'incident. ` +
          `Notre système de sécurité continue de surveiller le serveur.\n\n` +
          `Merci pour votre confiance envers **${client.user.username}**. 💙`
        )
        .setFooter({ text: `de l'équipe ${client.user.username}` });

      if (config?.supportLink) {
        embed.addFields({ name: 'Une question ?', value: config.supportLink });
      }

      user.send({ embeds: [embed] }).catch(() => null);
    }
  } else {
    await interaction.followUp(`❌ ${interaction.user} ne peut pas traiter cette demande pour le moment.`);
    if (user) {
      user.send('❌ Ta demande SOS n\'a pas pu être prise en charge pour le moment, réessaie ou contacte le staff autrement.').catch(() => null);
    }
  }

  return true;
};
