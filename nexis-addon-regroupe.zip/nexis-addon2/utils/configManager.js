const fs = require('fs');
const path = require('path');

// ⚠️ Sur Render (free tier), le système de fichiers est réinitialisé à chaque redéploiement.
// Si tu veux que la config survive aux redéploiements, il faudra migrer vers une vraie DB
// (ex: MongoDB Atlas gratuit) plus tard. Pour l'instant ça marche tant que le bot ne redéploie pas.

const configDir = path.join(__dirname, '..', 'data', 'configs');
if (!fs.existsSync(configDir)) fs.mkdirSync(configDir, { recursive: true });

function getConfigPath(guildId) {
  return path.join(configDir, `${guildId}.json`);
}

const defaultConfig = {
  grades: {},
  sosChannel: null,
  supportLink: null,
  ownerId: null,
  ownerChannels: [],
  lastOwnerAnnounce: 0
};

function loadConfig(guildId) {
  const filePath = getConfigPath(guildId);
  if (!fs.existsSync(filePath)) {
    return { ...defaultConfig };
  }
  try {
    return { ...defaultConfig, ...JSON.parse(fs.readFileSync(filePath, 'utf8')) };
  } catch {
    return { ...defaultConfig };
  }
}

function saveConfig(guildId, config) {
  fs.writeFileSync(getConfigPath(guildId), JSON.stringify(config, null, 2));
}

module.exports = { loadConfig, saveConfig };
