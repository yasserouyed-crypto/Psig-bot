# Server Manager V2

## Installation
1. Installe Node.js 18+.
2. Ouvre le dossier.
3. Lance `npm install`.
4. Remplis `config.json`.
5. Lance `node index.js`.

## Nouvelles fonctions V2
- Tickets avec panel bouton
- Fermeture/ajout/retrait de membres dans les tickets
- Giveaways avec durée, gagnants et reroll
- Annonces embed
- Sondages
- Gestion des rôles
- Liste staff
- Configuration bienvenue/départ
- Configuration AutoMod
- Raid mode + lockdown
- Modération et logs
- Blacklist persistante
- Preuves staff et rapports
