const {
  Client, GatewayIntentBits, Partials, PermissionsBitField,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, PermissionFlagsBits
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("./config.json");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel, Partials.Message]
});

const DATA = path.join(__dirname, "data");
const read = (f, fallback) => {
  const p = path.join(DATA, f);
  if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify(fallback, null, 2));
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return fallback; }
};
const write = (f, data) => fs.writeFileSync(path.join(DATA, f), JSON.stringify(data, null, 2));

let settings = read("config.json", {});
let blacklist = read("blacklist.json", {});
let warnings = read("warnings.json", {});
let proofs = read("preuves.json", {});
let tickets = read("tickets.json", {});
let giveaways = read("giveaways.json", {});
let mutes = read("mutes.json", {});

function guildSettings(guildId) {
  if (!settings[guildId]) {
    settings[guildId] = {
      automod: {...config.automod},
      raidMode: false,
      welcomeEnabled: true,
      goodbyeEnabled: true,
      welcomeMessage: "Bienvenue {user} sur **{server}** ! 👋",
      goodbyeMessage: "{user} vient de quitter **{server}**.",
      ticketCounter: 0,
      ticketCategoryId: config.ticketCategoryId,
      ticketStaffRoleId: config.ticketStaffRoleId
    };
    write("config.json", settings);
  }
  return settings[guildId];
}

const isStaff = m =>
  m.permissions.has(PermissionFlagsBits.Administrator) ||
  (config.staffRoleId && m.roles.cache.has(config.staffRoleId));

async function log(guild, title, description, color = 0x5865F2) {
  const s = guildSettings(guild.id);
  const channel = guild.channels.cache.get(config.logChannelId);
  if (!channel) return;
  const e = new EmbedBuilder()
    .setTitle(title).setDescription(description)
    .setColor(color).setTimestamp();
  try { await channel.send({embeds:[e]}); } catch {}
}

function cleanId(x) {
  return x?.replace(/[<@!#&>]/g, "");
}
function getMember(message, arg) {
  const id = cleanId(arg);
  return message.guild.members.cache.get(id) || message.mentions.members.first();
}
function reason(args, start=2) {
  return args.slice(start).join(" ") || "Aucune raison indiquée";
}
function userKey(guildId, userId) { return `${guildId}:${userId}`; }

client.once("ready", () => {
  console.log(`Connecté en tant que ${client.user.tag}`);
  client.user.setActivity("s!help | Server Manager V2");
});

client.on("guildMemberAdd", async member => {
  const s = guildSettings(member.guild.id);
  if (s.raidMode) {
    try { await member.timeout(60_000, "Raid mode actif"); } catch {}
  }
  if (s.welcomeEnabled && config.welcomeChannelId) {
    const ch = member.guild.channels.cache.get(config.welcomeChannelId);
    if (ch) {
      const text = s.welcomeMessage
        .replaceAll("{user}", `${member}`)
        .replaceAll("{server}", member.guild.name);
      ch.send(text).catch(()=>{});
    }
  }
  await log(member.guild, "👋 Arrivée", `${member} (${member.user.tag}) a rejoint le serveur.`);
});

client.on("guildMemberRemove", async member => {
  const s = guildSettings(member.guild.id);
  if (s.goodbyeEnabled && config.goodbyeChannelId) {
    const ch = member.guild.channels.cache.get(config.goodbyeChannelId);
    if (ch) {
      const text = s.goodbyeMessage
        .replaceAll("{user}", member.user.tag)
        .replaceAll("{server}", member.guild.name);
      ch.send(text).catch(()=>{});
    }
  }
  await log(member.guild, "📤 Départ", `**${member.user.tag}** a quitté le serveur.`);
});

const spam = new Map();

client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot) return;
  const s = guildSettings(message.guild.id);

  const key = userKey(message.guild.id, message.author.id);

  if (blacklist[key] && !isStaff(message.member)) {
    await message.delete().catch(()=>{});
    return;
  }

  if (s.automod.enabled && !isStaff(message.member)) {
    const content = message.content.toLowerCase();
    const link = /(https?:\/\/|www\.)/i.test(message.content);
    const invite = /(discord\.gg\/|discord\.com\/invite\/)/i.test(content);
    const bad = (s.automod.badWords || []).some(w => w && content.includes(w.toLowerCase()));
    const mentions = message.mentions.users.size + message.mentions.roles.size;

    if ((s.automod.antiLink && link) || (s.automod.antiInvite && invite) || bad || mentions > s.automod.maxMentions) {
      await message.delete().catch(()=>{});
      await log(message.guild, "🛡️ AutoMod", `Message supprimé de ${message.author} dans ${message.channel}.`, 0xED4245);
      return;
    }

    if (s.automod.antiSpam) {
      const now = Date.now();
      const arr = (spam.get(key) || []).filter(t => now - t < 6000);
      arr.push(now);
      spam.set(key, arr);
      if (arr.length >= 6) {
        spam.set(key, []);
        try { await message.member.timeout(60_000, "Anti-spam"); } catch {}
        await message.channel.send(`🛡️ ${message.author}, anti-spam activé. Timeout de 1 minute.`).catch(()=>{});
        await log(message.guild, "🚨 Anti-spam", `${message.author} a été timeout 1 minute.`);
        return;
      }
    }
  }

  if (!message.content.startsWith(config.prefix)) return;
  const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
  const cmd = (args.shift() || "").toLowerCase();

  if (cmd === "help") {
    const e = new EmbedBuilder().setTitle("🛠️ Server Manager V2")
      .setColor(0x5865F2)
      .setDescription([
        "**🛡️ Sécurité**",
        "`s!sos [motif]` `s!raidmode on/off` `s!lockdown` `s!unlockdown`",
        "`s!automod on/off` `s!antilink on/off` `s!antispam on/off`",
        "",
        "**🔨 Modération**",
        "`s!ban` `s!kick` `s!warn` `s!warnings` `s!clear` `s!timeout` `s!untimeout`",
        "`s!sanction` `s!blacklist` `s!unblacklist` `s!blacklistlist`",
        "",
        "**🎫 Tickets**",
        "`s!ticket` `s!close` `s!add` `s!remove` `s!ticketinfo`",
        "`s!ticketsetup #salon`",
        "",
        "**🎁 Giveaways**",
        "`s!giveaway <durée> <gagnants> <lot>`",
        "`s!endgiveaway <id>` `s!reroll <id>`",
        "",
        "**📢 Serveur**",
        "`s!announce #salon message` `s!say message` `s!poll question | choix1 | choix2`",
        "`s!role @membre @role` `s!unrole @membre @role`",
        "`s!userinfo` `s!serverinfo`",
        "",
        "**👮 Staff**",
        "`s!staffpreuve` `s!rapport` `s!stafflist`",
        "",
        "**⚙️ Configuration**",
        "`s!config` `s!welcome on/off` `s!goodbye on/off`"
      ].join("\n"));
    return message.reply({embeds:[e]});
  }

  if (["sos","raidmode","lockdown","unlockdown","staffpreuve","rapport","sanction","ban","unban","kick","warn","warnings","clear","timeout","untimeout","blacklist","unblacklist","blacklistlist","automod","antilink","antispam","ticketsetup","announce","say","role","unrole","welcome","goodbye","giveaway","endgiveaway","reroll"].includes(cmd) && !isStaff(message.member)) {
    return message.reply("❌ Tu dois être membre du staff pour utiliser cette commande.");
  }

  if (cmd === "sos") {
    const motif = args.join(" ") || "Urgence raid";
    const content = config.mentionEveryoneOnSOS ? "@everyone " : "";
    await message.channel.send({content: `${content}🚨 **SOS RAID** — ${motif}`});
    await log(message.guild, "🚨 SOS RAID", `${message.author} : ${motif}`, 0xED4245);
    return;
  }

  if (cmd === "raidmode") {
    const value = args[0]?.toLowerCase();
    if (!["on","off"].includes(value)) return message.reply("Utilisation : `s!raidmode on/off`");
    s.raidMode = value === "on"; write("config.json", settings);
    await log(message.guild, "🛡️ Raid Mode", `${message.author} → ${value.toUpperCase()}`, 0xFEE75C);
    return message.reply(`🛡️ Raid Mode **${value === "on" ? "activé" : "désactivé"}**.`);
  }

  if (cmd === "lockdown" || cmd === "unlockdown") {
    const lock = cmd === "lockdown";
    let count = 0;
    for (const ch of message.guild.channels.cache.values()) {
      if (![ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(ch.type)) continue;
      try {
        await ch.permissionOverwrites.edit(message.guild.roles.everyone, {
          SendMessages: lock ? false : null
        });
        count++;
      } catch {}
    }
    await log(message.guild, lock ? "🔒 Lockdown" : "🔓 Unlockdown", `${message.author} a ${lock ? "bloqué" : "débloqué"} ${count} salons.`);
    return message.reply(`${lock ? "🔒" : "🔓"} ${count} salons traités.`);
  }

  if (cmd === "staffpreuve") {
    const member = getMember(message, args[0]);
    if (!member) return message.reply("Utilisation : `s!staffpreuve @membre preuve`");
    const proof = reason(args, 1);
    proofs[Date.now()] = {guildId:message.guild.id, memberId:member.id, staffId:message.author.id, proof, date:new Date().toISOString()};
    write("preuves.json", proofs);
    await log(message.guild, "📁 Preuve staff", `${message.author} → ${member}\n**Preuve :** ${proof}`);
    return message.reply("✅ Preuve enregistrée.");
  }

  if (cmd === "rapport" || cmd === "sanction") {
    const text = args.join(" ") || "Aucun contenu.";
    await log(message.guild, cmd === "rapport" ? "📝 Rapport staff" : "⚖️ Sanction", `${message.author}\n${text}`);
    return message.reply("✅ Enregistré dans les logs.");
  }

  if (cmd === "ban" || cmd === "kick" || cmd === "timeout" || cmd === "untimeout" || cmd === "warn") {
    const member = getMember(message, args[0]);
    if (!member) return message.reply(`Utilisation : \`${config.prefix}${cmd} @membre [raison]\``);
    const why = reason(args);
    try {
      if (cmd === "ban") await member.ban({reason:why});
      if (cmd === "kick") await member.kick(why);
      if (cmd === "timeout") await member.timeout(10*60*1000, why);
      if (cmd === "untimeout") await member.timeout(null, why);
      if (cmd === "warn") {
        const k = userKey(message.guild.id, member.id);
        warnings[k] = warnings[k] || [];
        warnings[k].push({staff:message.author.id, reason:why, date:new Date().toISOString()});
        write("warnings.json", warnings);
      }
      await log(message.guild, `🔨 ${cmd.toUpperCase()}`, `${message.author} → ${member}\n**Raison :** ${why}`, 0xED4245);
      return message.reply(`✅ ${cmd} effectué sur ${member}.`);
    } catch (e) { return message.reply("❌ Action impossible. Vérifie mes permissions et la hiérarchie des rôles."); }
  }

  if (cmd === "unban") {
    const id = cleanId(args[0]);
    if (!id) return message.reply("Utilisation : `s!unban ID`");
    try { await message.guild.members.unban(id); return message.reply("✅ Utilisateur débanni."); }
    catch { return message.reply("❌ Impossible de débannir cet utilisateur."); }
  }

  if (cmd === "warnings") {
    const member = getMember(message, args[0]) || message.member;
    const list = warnings[userKey(message.guild.id, member.id)] || [];
    return message.reply(list.length ? `⚠️ **${member.user.tag}** :\n` + list.map((x,i)=>`${i+1}. ${x.reason}`).join("\n") : "✅ Aucun avertissement.");
  }

  if (cmd === "clear") {
    const n = Math.min(Math.max(parseInt(args[0]) || 10, 1), 100);
    const deleted = await message.channel.bulkDelete(n, true).catch(()=>null);
    return message.reply(`🧹 ${deleted?.size || 0} messages supprimés.`).then(m=>setTimeout(()=>m.delete().catch(()=>{}),3000));
  }

  if (cmd === "blacklist") {
    const member = getMember(message, args[0]);
    if (!member) return message.reply("Utilisation : `s!blacklist @membre [raison]`");
    const why = reason(args);
    blacklist[userKey(message.guild.id, member.id)] = {memberId:member.id, reason:why, staffId:message.author.id, date:new Date().toISOString()};
    write("blacklist.json", blacklist);
    if (config.blacklistRoleId) await member.roles.add(config.blacklistRoleId).catch(()=>{});
    await log(message.guild, "⛔ Blacklist", `${member} — ${why}`, 0xED4245);
    return message.reply("⛔ Membre ajouté à la blacklist.");
  }

  if (cmd === "unblacklist") {
    const member = getMember(message, args[0]);
    if (!member) return message.reply("Utilisation : `s!unblacklist @membre`");
    delete blacklist[userKey(message.guild.id, member.id)];
    write("blacklist.json", blacklist);
    if (config.blacklistRoleId) await member.roles.remove(config.blacklistRoleId).catch(()=>{});
    return message.reply("✅ Membre retiré de la blacklist.");
  }

  if (cmd === "blacklistlist") {
    const list = Object.values(blacklist).filter(x=>x.guildId===message.guild.id || x.memberId);
    return message.reply(list.length ? list.map(x=>`• <@${x.memberId}> — ${x.reason}`).join("\n").slice(0,1900) : "✅ Blacklist vide.");
  }

  if (["automod","antilink","antispam"].includes(cmd)) {
    const value = args[0]?.toLowerCase();
    if (!["on","off"].includes(value)) return message.reply(`Utilisation : \`${config.prefix}${cmd} on/off\``);
    const prop = cmd === "automod" ? "enabled" : cmd === "antilink" ? "antiLink" : "antiSpam";
    s.automod[prop] = value === "on"; write("config.json", settings);
    return message.reply(`🛡️ ${cmd} ${value === "on" ? "activé" : "désactivé"}.`);
  }

  if (cmd === "userinfo") {
    const m = getMember(message, args[0]) || message.member;
    const e = new EmbedBuilder().setTitle("👤 UserInfo").setColor(0x5865F2)
      .setThumbnail(m.user.displayAvatarURL())
      .addFields(
        {name:"Utilisateur", value:`${m.user.tag}`, inline:true},
        {name:"ID", value:m.id, inline:true},
        {name:"Compte créé", value:`<t:${Math.floor(m.user.createdTimestamp/1000)}:F>`},
        {name:"Arrivée", value:m.joinedTimestamp ? `<t:${Math.floor(m.joinedTimestamp/1000)}:F>` : "Inconnue"}
      );
    return message.reply({embeds:[e]});
  }

  if (cmd === "serverinfo") {
    const e = new EmbedBuilder().setTitle(`📊 ${message.guild.name}`).setColor(0x5865F2)
      .addFields(
        {name:"Membres", value:String(message.guild.memberCount), inline:true},
        {name:"Salons", value:String(message.guild.channels.cache.size), inline:true},
        {name:"Rôles", value:String(message.guild.roles.cache.size), inline:true},
        {name:"Créé le", value:`<t:${Math.floor(message.guild.createdTimestamp/1000)}:D>`}
      );
    return message.reply({embeds:[e]});
  }

  if (cmd === "ticketsetup") {
    const ch = message.mentions.channels.first();
    if (!ch) return message.reply("Utilisation : `s!ticketsetup #salon`");
    s.ticketPanelChannelId = ch.id; write("config.json", settings);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("ticket_open").setLabel("Ouvrir un ticket").setEmoji("🎫").setStyle(ButtonStyle.Primary)
    );
    const e = new EmbedBuilder().setTitle("🎫 Support").setDescription("Clique sur le bouton ci-dessous pour ouvrir un ticket.").setColor(0x5865F2);
    await ch.send({embeds:[e],components:[row]});
    return message.reply("✅ Panel ticket installé.");
  }

  if (cmd === "ticket") return createTicket(message);

  if (cmd === "close") {
    if (!message.channel.name?.startsWith("ticket-")) return message.reply("❌ Cette commande doit être utilisée dans un ticket.");
    await message.channel.delete().catch(()=>{});
    return;
  }

  if (cmd === "add" || cmd === "remove") {
    if (!message.channel.name?.startsWith("ticket-")) return message.reply("❌ Utilise cette commande dans un ticket.");
    const member = getMember(message, args[0]);
    if (!member) return message.reply("❌ Membre introuvable.");
    await message.channel.permissionOverwrites.edit(member.id, {ViewChannel: cmd==="add", SendMessages: cmd==="add"});
    return message.reply(`✅ ${member} ${cmd==="add"?"ajouté au":"retiré du"} ticket.`);
  }

  if (cmd === "announce") {
    const ch = message.mentions.channels.first();
    const text = args.slice(1).join(" ");
    if (!ch || !text) return message.reply("Utilisation : `s!announce #salon message`");
    const e = new EmbedBuilder().setTitle("📢 Annonce").setDescription(text).setColor(0x5865F2).setTimestamp();
    await ch.send({embeds:[e]});
    return message.reply("✅ Annonce envoyée.");
  }

  if (cmd === "say") {
    const text = args.join(" ");
    if (!text) return message.reply("Utilisation : `s!say message`");
    await message.delete().catch(()=>{});
    return message.channel.send(text);
  }

  if (cmd === "poll") {
    const parts = message.content.slice(config.prefix.length + cmd.length).trim().split("|").map(x=>x.trim()).filter(Boolean);
    if (parts.length < 3) return message.reply("Utilisation : `s!poll question | choix1 | choix2`");
    const [question,...choices] = parts;
    const emojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣"];
    const desc = choices.slice(0,5).map((x,i)=>`${emojis[i]} ${x}`).join("\n");
    const e = new EmbedBuilder().setTitle("📊 Sondage").setDescription(`**${question}**\n\n${desc}`).setColor(0x5865F2);
    const poll = await message.channel.send({embeds:[e]});
    for (let i=0;i<Math.min(choices.length,5);i++) await poll.react(emojis[i]).catch(()=>{});
    return;
  }

  if (cmd === "role" || cmd === "unrole") {
    const member = getMember(message, args[0]);
    const role = message.mentions.roles.first();
    if (!member || !role) return message.reply(`Utilisation : \`${config.prefix}${cmd} @membre @role\``);
    try {
      if (cmd === "role") await member.roles.add(role);
      else await member.roles.remove(role);
      return message.reply(`✅ Rôle ${cmd==="role"?"ajouté":"retiré"}.`);
    } catch { return message.reply("❌ Je ne peux pas gérer ce rôle (hiérarchie/permissions)."); }
  }

  if (cmd === "stafflist") {
    const role = message.guild.roles.cache.get(config.staffRoleId);
    if (!role) return message.reply("❌ Role staff non configuré.");
    const members = role.members.map(m=>`• ${m}`).join("\n") || "Aucun membre.";
    return message.reply(`👮 **Staff (${role.name})**\n${members}`.slice(0,1900));
  }

  if (cmd === "welcome" || cmd === "goodbye") {
    const value = args[0]?.toLowerCase();
    if (!["on","off"].includes(value)) return message.reply(`Utilisation : \`${config.prefix}${cmd} on/off\``);
    s[cmd==="welcome"?"welcomeEnabled":"goodbyeEnabled"] = value === "on";
    write("config.json", settings);
    return message.reply(`✅ ${cmd} ${value==="on"?"activé":"désactivé"}.`);
  }

  if (cmd === "config") {
    const e = new EmbedBuilder().setTitle("⚙️ Configuration")
      .setColor(0x5865F2)
      .setDescription([
        `AutoMod : **${s.automod.enabled ? "ON":"OFF"}**`,
        `Anti-liens : **${s.automod.antiLink ? "ON":"OFF"}**`,
        `Anti-spam : **${s.automod.antiSpam ? "ON":"OFF"}**`,
        `Raid Mode : **${s.raidMode ? "ON":"OFF"}**`,
        `Bienvenue : **${s.welcomeEnabled ? "ON":"OFF"}**`,
        `Départ : **${s.goodbyeEnabled ? "ON":"OFF"}**`
      ].join("\n"));
    return message.reply({embeds:[e]});
  }

  if (cmd === "giveaway") return createGiveaway(message, args);
  if (cmd === "endgiveaway") return endGiveaway(message, args[0]);
  if (cmd === "reroll") return rerollGiveaway(message, args[0]);
});

async function createTicket(message) {
  const s = guildSettings(message.guild.id);
  const existing = message.guild.channels.cache.find(c=>c.topic === `ticket:${message.author.id}`);
  if (existing) return message.reply(`❌ Tu as déjà un ticket : ${existing}`);

  s.ticketCounter = (s.ticketCounter || 0) + 1;
  write("config.json", settings);
  const channel = await message.guild.channels.create({
    name:`ticket-${s.ticketCounter}`,
    type:ChannelType.GuildText,
    parent: s.ticketCategoryId && message.guild.channels.cache.has(s.ticketCategoryId) ? s.ticketCategoryId : null,
    topic:`ticket:${message.author.id}`,
    permissionOverwrites:[
      {id:message.guild.roles.everyone.id, deny:[PermissionFlagsBits.ViewChannel]},
      {id:message.author.id, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]},
      ...(s.ticketStaffRoleId ? [{id:s.ticketStaffRoleId, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]}] : [])
    ]
  });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_close").setLabel("Fermer").setEmoji("🔒").setStyle(ButtonStyle.Danger)
  );
  const e = new EmbedBuilder().setTitle("🎫 Ticket ouvert").setDescription(`Bonjour ${message.author} !\nExplique ton problème et un membre du staff va te répondre.`).setColor(0x5865F2);
  await channel.send({content:`${message.author}`,embeds:[e],components:[row]});
  await log(message.guild,"🎫 Ticket",`${message.author} a ouvert ${channel}.`);
  return message.reply(`✅ Ticket créé : ${channel}`);
}

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;

  if (interaction.customId === "ticket_open") {
    await interaction.deferReply({ephemeral:true});
    const fake = {guild:interaction.guild, author:interaction.user, reply:async x=>interaction.editReply(x)};
    return createTicket(fake);
  }

  if (interaction.customId === "ticket_close") {
    if (!interaction.channel?.name?.startsWith("ticket-")) return interaction.reply({content:"❌ Pas un ticket.",ephemeral:true});
    await interaction.reply("🔒 Fermeture du ticket...");
    setTimeout(()=>interaction.channel.delete().catch(()=>{}),1500);
  }
});

function parseDuration(str) {
  const m = /^(\d+)(s|m|h|d)$/i.exec(str || "");
  if (!m) return null;
  const n = Number(m[1]);
  return n * ({s:1000,m:60000,h:3600000,d:86400000})[m[2].toLowerCase()];
}

async function createGiveaway(message,args) {
  const duration = parseDuration(args[0]);
  const winners = Math.max(1, Math.min(20, Number(args[1]) || 1));
  const prize = args.slice(2).join(" ");
  if (!duration || !prize) return message.reply("Utilisation : `s!giveaway 1h 1 Nitro`");
  const id = String(Date.now());
  const end = Date.now()+duration;
  giveaways[id] = {id,guildId:message.guild.id,channelId:message.channel.id,messageId:null,host:message.author.id,winners,prize,end,ended:false};
  write("giveaways.json",giveaways);
  const e = new EmbedBuilder().setTitle("🎁 GIVEAWAY").setDescription(`**Lot :** ${prize}\n**Gagnants :** ${winners}\n**Organisé par :** ${message.author}\n\nRéagis avec 🎉 pour participer.\nFin : <t:${Math.floor(end/1000)}:R>`).setColor(0xFEE75C);
  const msg = await message.channel.send({embeds:[e]});
  await msg.react("🎉");
  giveaways[id].messageId=msg.id; write("giveaways.json",giveaways);
  setTimeout(()=>finishGiveaway(id), duration);
  return message.reply(`✅ Giveaway créé. ID : \`${id}\``);
}

async function finishGiveaway(id) {
  const g = giveaways[id];
  if (!g || g.ended) return;
  const channel = client.channels.cache.get(g.channelId);
  const msg = await channel?.messages.fetch(g.messageId).catch(()=>null);
  const users = msg ? (await msg.reactions.cache.get("🎉")?.users.fetch().catch(()=>null)) : null;
  const candidates = users ? [...users.filter(u=>!u.bot).values()] : [];
  const shuffled = candidates.sort(()=>Math.random()-0.5);
  const winners = shuffled.slice(0,g.winners);
  g.ended=true; g.winnerIds=winners.map(u=>u.id); write("giveaways.json",giveaways);
  if (channel) await channel.send(winners.length ? `🎉 Giveaway terminé ! Gagnant(s) : ${winners.map(u=>`<@${u.id}>`).join(", ")} — **${g.prize}**` : "❌ Giveaway terminé, aucun participant.");
}

async function endGiveaway(message,id) {
  if (!id || !giveaways[id]) return message.reply("❌ ID de giveaway invalide.");
  await finishGiveaway(id);
  return message.reply("✅ Giveaway terminé.");
}

async function rerollGiveaway(message,id) {
  const g=giveaways[id];
  if (!g || !g.ended) return message.reply("❌ Giveaway terminé introuvable.");
  const ch=message.guild.channels.cache.get(g.channelId);
  const msg=await ch?.messages.fetch(g.messageId).catch(()=>null);
  const users=msg ? await msg.reactions.cache.get("🎉")?.users.fetch().catch(()=>null) : null;
  const candidates=users ? [...users.filter(u=>!u.bot && !g.winnerIds.includes(u.id)).values()] : [];
  const winner=candidates[Math.floor(Math.random()*candidates.length)];
  return message.reply(winner ? `🎉 Nouveau gagnant : ${winner} — **${g.prize}**` : "❌ Aucun autre participant.");
}

client.login(config.token);
